package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by 讯 on 2017/4/17.
 */
@Controller
@RequestMapping("/manage")
public class ManageController {


}
