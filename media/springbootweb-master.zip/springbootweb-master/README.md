This programme named Ebbs is developed by springboot based on thymeleaf in front
